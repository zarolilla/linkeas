import './App.css'
import { Routes, Route } from 'react-router-dom';

import Header from './components/Header/Header'
import Footer from './components/Footer/Fotter'
import Login from './components/login/Login'
import Register from './components/Register/Register';
import PostSearch from './components/PostSearch/PostSearch'
import NotFound from './NotFound/NotFound';
import PostCreate from './components/postCreate/PostCreate';
import EditUser from './components/editUser/editUser';
import 'bootstrap-icons/font/bootstrap-icons.css';
import GetUser from './components/user/user'








function App() {
  return (
    <div className="App">
      <Header/>
      <Routes>
        <Route path='/' element={<PostSearch/>} />
        <Route path='/register' element={<Register/>} />
        <Route path='/user' element={<GetUser/>} />
        <Route path='/edite' element={<EditUser/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/newpost' element={<PostCreate/>} />
        <Route path='*' element={<NotFound/>} />
       

      </Routes>
      <Footer/>
    </div>
  )
}

export default App
