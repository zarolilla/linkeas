import { useState } from 'react';
import { useToken } from '../../context/Authcontext';
import { NavLink } from 'react-router-dom';
import { deletePost } from '../../services/deletePost';
import { likePosts } from '../../services/likePosts';

import './Post.css';

const Post = ({ post, posts, setPosts }) => {
  const { token, user } = useToken();
  const [loading, setLoading] = useState(false);
  const [likedByMe, setLikedByMe] = useState(post.likedByMe || false);
  const [likes, setLikes] = useState(post.likes !== null && post.likes !== undefined ? post.likes : 0);

  const handleLike = async (e, postId, likedByMe) => {
    
    setLoading(true);
    e.target.classList.toggle('like');
    const like = await likePosts(postId, likedByMe, token);

    if (like) {
      setLikedByMe(!likedByMe);
      setLikes(prevLikes => likedByMe ? prevLikes - 1 : prevLikes + 1);
    }

    setLoading(false);
  };

  const handleDeletePost = async (postId) => {
    setLoading(true);

    if (confirm('¿Quieres borrar esta publicación?')) {
      const deletedPost = await deletePost(postId, token);

      if (deletedPost) {
        setPosts(posts.filter((post) => post.id !== postId));
      }
    }

    setLoading(false);
  };
 


  return (
    <li className='post' key={post.id}>
      <header>
        <div><img className='usuario' src="src/assets/Profile-Avatar-PNG.png" alt="avatar" />  </div>
        <p>@{post.name} </p>
      </header>
      <div >
        <h2 className='title'>{post.title} </h2>
        <p className='description'>{post.description}</p>
        <p className='enlace'>Enlace</p>
        
        
        <a className='link' href={post.link} target="_blank">{post.link}</a>
      </div>
      <time dateTime={post.createdAt}>
        {new Date(post.createdAt).toLocaleDateString('es-ES',{
            day: '2-digit',
            month:'2-digit',
            year: '2-digit',
        })}
      </time>
      <footer>
        <div>
          <div
            className={`heart ${likedByMe && 'like'}`}
            onClick={(e) => {
              if (!loading && token) {
                handleLike(e, post.id, likedByMe);
              }
            }}
          ></div>
          <p>{likes}</p>
        </div>
        
        {user.id === post.userId && (
          <button
            onClick={(e) => handleDeletePost(post.id)}
            disabled={loading}>Eliminar</button>
        )}
      </footer>
    </li>
  );
};

export default Post;