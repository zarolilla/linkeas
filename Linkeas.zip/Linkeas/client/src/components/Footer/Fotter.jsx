import './Footer.css';

const Footer =() => {
    return (
        <footer className='footer-footer'>
            <p>&copy;David Zarola Compartir_enlaces</p>
        </footer>
    );
}

export default Footer;