import { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToken } from '../../context/Authcontext/';
import { editUser } from '../../services/editUser';




const EditUser = () => {
    const { token} = useToken();
    const navigate = useNavigate();
    
    
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [biografia,setBiografia] = useState('');
    const [file, setFile] = useState();
    const [loading, setLoading] = useState(false);

    useEffect(()=>{
        if (!token){
            navigate('/login');
        }
    }
    )


    const handleSubmit = async (e) => {
        e.preventDefault();

        setLoading(true);

        const editedUser = await editUser(name,email,file,biografia, token);

        
         if (editedUser) {
        navigate('/');
        setLoading(false);
        window.location.reload();
        }
    };

    return (
        <main className='newpost'>
            <form onSubmit={handleSubmit}>
                <h2>Editar Usuario</h2>
                
                <label htmlFor="name">Nuevo Nombre</label>
                <input
                    id='name'
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    minLength='5'
                    autoFocus
                    required
                    placeholder='name'
                />
                <label htmlFor="email">Nuevo email</label>
                <input
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    minLength='6'
                    autoFocus
                    required
                    placeholder='email'
                />
                <label htmlFor="biografia">Biografia</label>
                <textarea
                    value={biografia}
                    onChange={(e) => setBiografia(e.target.value)}
                    minLength='10'
                    autoFocus
                    required
                    placeholder='algo de ti...'
                />
                <label htmlFor="file">avatar</label>
                <input 
                    type='file'
                    onChange={(e)=> setFile(e.target.files[0]) }
                />

                <button className='enviar' disabled={loading}>editar</button>
            </form>
        </main>
    );
};

export default EditUser;