import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useToken } from '../../context/Authcontext';
import './user.css';





const GetUser =() => {
    const {token,setTokenInLocal,user} = useToken();
    const [userData, setUserData] = useState(null);

    useEffect(()=>{
        setUserData(user);
    },[user]);
    console.log(user);

    return (
        <main className='userdata'>
            <section>

         {token&&(
             
             <ul className='list-user-data'>
               {userData && <>
               <li><h3> Nombre:</h3>{user.name}</li>
               <li><h3>Corrreo:</h3>{user.email}</li>
               <li><h3>Biografia:</h3>{user.biografia}</li> 
               <li><h3>Avatar</h3>{user.avatar}</li>
               <div className='buttons-post edit'>
                           <NavLink className={'new-post-buttons'} to ='/edite'>editar</NavLink>
               </div>
               </>
               }
               </ul>
             )}
             </section>
        </main>
            
            
                
             
             
                
               
                
               
                
        

    );
}

export default GetUser;