require('dotenv').config();
const cors = require('cors');
const express = require('express');
const fileUpload = require('express-fileupload');
const app = express();

const { PORT, UPLOADS_DIR } = process.env;
app.use(cors());
app.use(express.static(UPLOADS_DIR));

app.use(express.json());
app.use(fileUpload());

const {
  getPosts,
  createPost,
  deletePost,
  editPost,
  getPost,
} = require('./controllers/post');

const {
  createUser,
  loginUser,
  activateUser,
  deleteUser,
  getOwnUser,
  editUser,
} = require('./controllers/users');

const { togglePostLike } = require('./controllers/likes');

const {
  handleError,
  handleNotFound,
  validateAuth,
  checkAdmin,
  userExists,
  canEditUser,
} = require('./middlewares');
const { selectUserById } = require('./repositories/users');

//controladores usuarios
app.get('/activate/:registrationCode', activateUser);
app.post('/users', createUser);
app.delete('/users/:id', validateAuth, checkAdmin, deleteUser);
app.post('/login', loginUser);
app.get('/users', validateAuth, getOwnUser);
app.get('/users/:id', selectUserById);
app.put('/users', validateAuth, editUser);

//controladores post
app.get('/posts', getPosts);
app.get('/posts/:id', getPost);
app.post('/posts/:id/like', validateAuth, togglePostLike);
app.delete('/posts/:id/like', validateAuth, togglePostLike);
app.post('/posts', validateAuth, createPost);
app.delete('/posts/:id', validateAuth, deletePost);
app.put('/posts/:id', validateAuth, editPost);

app.use(handleNotFound);

app.use(handleError);

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
