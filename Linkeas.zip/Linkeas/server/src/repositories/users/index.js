const insertUser = require('./insertUser');
const deleteRegistrationCode = require('./deleteRegistrationCode');
const selectUserByRegistrationCode = require('./selectUserByRegistrationCode');
const selectUserById = require('./selectUserById');
const deleteUserById = require('./deleteUserById');
const selectUserByEmail = require('./selectUserByEmail');

module.exports = {
  insertUser,
  deleteRegistrationCode,
  selectUserByRegistrationCode,
  selectUserById,
  deleteUserById,
  selectUserByEmail,
};
