const Joi = require('joi');

const createPostSchema = Joi.object({
  title: Joi.string().min(4).max(100).required().messages({
    'string.min': 'titulo tiene menos de 4 caracteres',
    'string.max': 'el titulo supera los 100 caracteres',
    'any.required': 'Tienes que poner un titulo',
    'string.base': 'Title has to be a string',
  }),
  description: Joi.string().min(10).max(600).required().messages({
    'string.min':
      '¡¡La descripcion es demasiado corta!! escribete algo mas -TU PUEDES-😀',
    'string.max': 'La Descripcion es demasiado larga',
    'any.required': ' La descripcion es obligatoria',
    'string.base': 'Descripcion tiene que ser un string',
  }),
  link: Joi.string().min(8).max(5000).required().messages({
    'string.min': 'url es muy corta',
    'string.max': 'url es demasiado largo',
    'any.required': 'El link es obligatorio',
    'string.base': 'url tiene que ser un string',
  }),
});

module.exports = createPostSchema;
