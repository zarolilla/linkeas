const createUserSchema = require('./createUserSchema');
const loginUserSchema = require('./loginUserSchema');
const userIdSchema = require('./userIdSchema');
const filterUsersSchema = require('./filterUsersSchema');

module.exports = {
  createUserSchema,
  loginUserSchema,
  userIdSchema,
  filterUsersSchema,
};
