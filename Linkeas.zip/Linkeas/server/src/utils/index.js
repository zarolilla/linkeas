const generateError = require('./generateError');

const sendMail = require('./sendMail');
const saveAndDeletePhoto = './saveAndDeletePhoto';

module.exports = { generateError, sendMail, saveAndDeletePhoto };
